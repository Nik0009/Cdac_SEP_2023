package lifeCycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.springframework.web.bind.annotation.PostMapping;

public class LifeCycleDemo {
    private int x;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        System.out.println("setter");
        this.x = x;
    }
    
    @PostConstruct
    public void startaa(){
        System.out.println("INIT Method Invoked");
    }
    
    @PreDestroy
    public void stopbb(){
        System.out.println("Destroy Method Invoked");
    }
}
