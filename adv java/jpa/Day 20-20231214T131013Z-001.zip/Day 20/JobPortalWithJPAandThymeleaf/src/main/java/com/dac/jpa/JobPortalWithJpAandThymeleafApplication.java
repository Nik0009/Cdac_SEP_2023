package com.dac.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalWithJpAandThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalWithJpAandThymeleafApplication.class, args);
	}

}
