package com.dac.crud.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobPortalWithJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobPortalWithJdbcApplication.class, args);
	}

}
