package com.dac.crud.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalWithJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
