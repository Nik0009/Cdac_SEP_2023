package com.dac.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.dac.security.model.User;
import com.dac.security.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;

	public List<User> getAllUsers() {
		List<User> list=(List<User>)userRepository.findAll();
		return list;
	}

	public User getUser(String name) {
		return userRepository.findByUsername(name);
	}

	public User addUser(User user) {
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		User u=userRepository.save(user);
		return u;
	}
	
	
}
