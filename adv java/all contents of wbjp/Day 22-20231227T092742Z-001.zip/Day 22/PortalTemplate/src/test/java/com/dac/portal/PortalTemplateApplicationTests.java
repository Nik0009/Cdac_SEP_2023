package com.dac.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
