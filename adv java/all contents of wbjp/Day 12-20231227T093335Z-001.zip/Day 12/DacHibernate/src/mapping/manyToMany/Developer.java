package mapping.manyToMany;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Developer {
    @Id
    private int dId;
    private String name;
    
    @ManyToMany
    @JoinTable(name = "Dev_Pro",joinColumns ={@JoinColumn(name = "dId")},inverseJoinColumns = {@JoinColumn(name = "pId")} )
    private List<Projects> projects;

    public int getdId() {
        return dId;
    }

    public void setdId(int dId) {
        this.dId = dId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Projects> getProjects() {
        return projects;
    }

    public void setProjects(List<Projects> projects) {
        this.projects = projects;
    }
    
}
