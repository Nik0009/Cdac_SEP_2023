package mapping.oneToMany;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class TestOneToMany {
    public static void main(String[] args) {
        AnnotationConfiguration config=new AnnotationConfiguration();
        config.configure("hibernate.cfg.xml");
        SessionFactory sf=config.buildSessionFactory();
        Session s=sf.openSession();
//        Transaction tc=s.beginTransaction();
//        
//        College clg=new College();
//                clg.setcId(110011);
//                clg.setcName("YCCE");
//                
//        ColStudent stud1=new ColStudent();
//                stud1.setsId(101);
//                stud1.setsName("Ramesh");
//                stud1.setsRollNo(12345);
//                stud1.setCollege(clg);
//                
//        ColStudent stud2=new ColStudent();
//                stud2.setsId(102);
//                stud2.setsName("Suresh");
//                stud2.setsRollNo(54321);
//                stud2.setCollege(clg);
//                
//        ColStudent stud3=new ColStudent();
//                stud3.setsId(103);
//                stud3.setsName("Dinesh");
//                stud3.setsRollNo(23451);
//                stud3.setCollege(clg);
//                
//        List<ColStudent> students=new ArrayList<>();
//        students.add(stud1);
//        students.add(stud2);
//        students.add(stud3);
//        
//        clg.setStudents(students);
//        
//        s.save(clg);
//       
//        
//        tc.commit();
        College c=(College)s.get(College.class, 110011);
        System.out.println(c.getcName());
        for(ColStudent stud:c.getStudents()){
        System.out.println(stud.getsName());
        }
        s.close();
    }
}
